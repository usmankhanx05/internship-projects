package com.maanoavte.taskify

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
