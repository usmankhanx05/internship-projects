import 'package:flutter/material.dart';

enum TaskPriority { low, medium, high }
enum TaskFilter { all, pending, completed, highPriority }

extension TaskPriorityX on TaskPriority {
  String get label {
    switch (this) {
      case TaskPriority.low:
        return 'Low';
      case TaskPriority.medium:
        return 'Medium';
      case TaskPriority.high:
        return 'High';
    }
  }

  Color get color {
    switch (this) {
      case TaskPriority.low:
        return const Color(0xFF2ECC71);
      case TaskPriority.medium:
        return const Color(0xFFF39C12);
      case TaskPriority.high:
        return const Color(0xFFE74C3C);
    }
  }

  IconData get icon {
    switch (this) {
      case TaskPriority.low:
        return Icons.keyboard_arrow_down_rounded;
      case TaskPriority.medium:
        return Icons.drag_handle_rounded;
      case TaskPriority.high:
        return Icons.keyboard_arrow_up_rounded;
    }
  }
}

extension TaskFilterX on TaskFilter {
  String get label {
    switch (this) {
      case TaskFilter.all:
        return 'All';
      case TaskFilter.pending:
        return 'Pending';
      case TaskFilter.completed:
        return 'Completed';
      case TaskFilter.highPriority:
        return 'High Priority';
    }
  }
}

class TaskModel {
  final String id;
  final String title;
  final String note;
  final String category;
  final TaskPriority priority;
  final bool isDone;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? dueDate;

  TaskModel({
    required this.id,
    required this.title,
    this.note = '',
    this.category = 'General',
    this.priority = TaskPriority.medium,
    this.isDone = false,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.dueDate,
  })  : createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  TaskModel copyWith({
    String? title,
    String? note,
    String? category,
    TaskPriority? priority,
    bool? isDone,
    DateTime? createdAt,
    DateTime? updatedAt,
    DateTime? dueDate,
  }) {
    return TaskModel(
      id: id,
      title: title ?? this.title,
      note: note ?? this.note,
      category: category ?? this.category,
      priority: priority ?? this.priority,
      isDone: isDone ?? this.isDone,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      dueDate: dueDate ?? this.dueDate,
    );
  }

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'note': note,
    'category': category,
    'priority': priority.index,
    'isDone': isDone ? 1 : 0,
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
    'dueDate': dueDate?.toIso8601String(),
  };

  factory TaskModel.fromMap(Map<String, dynamic> map) {
    return TaskModel(
      id: map['id']?.toString() ?? '',
      title: map['title']?.toString() ?? '',
      note: map['note']?.toString() ?? '',
      category: map['category']?.toString() ?? 'General',
      priority: TaskPriority.values[(map['priority'] as int?) ?? 1],
      isDone: map['isDone'] == 1 || map['isDone'] == true,
      createdAt: DateTime.tryParse(map['createdAt']?.toString() ?? '') ?? DateTime.now(),
      updatedAt: DateTime.tryParse(map['updatedAt']?.toString() ?? '') ?? DateTime.now(),
      dueDate: map['dueDate'] == null
          ? null
          : DateTime.tryParse(map['dueDate'].toString()),
    );
  }
}