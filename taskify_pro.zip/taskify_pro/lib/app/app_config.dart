class AppConfig {
  // ================== ADMOB ==================

  // 🔥 Toggle test/real ads
  static const bool useTestAds = false;

  // ✅ TEST IDs (Google official)
  static const String testBanner =
      'ca-app-pub-3940256099942544/6300978111';

  static const String testInterstitial =
      'ca-app-pub-3940256099942544/1033173712';

  // ✅ YOUR REAL IDs
  static const String realBanner =
      'ca-app-pub-5192844554089374/2206093251';

  static const String realInterstitial =
      'ca-app-pub-5192844554089374/1825017557';

  // ================== SUPABASE ==================

  // 🔥 Enable ONLY when you want cloud sync
  static const bool enableSupabaseSync = false;

  // 🔑 Your Supabase credentials
  static const String supabaseUrl =
      'https://xgpcyxuahtpoerjletuz.supabase.co';

  static const String supabaseAnonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhncGN5eHVhaHRwb2VyamxldHV6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ0NTcwMzUsImV4cCI6MjA5MDAzMzAzNX0.zsXvYWD8Xv_CMA_-g9cb1IkKophRSj6xmkFgVDkhn6Y';
}