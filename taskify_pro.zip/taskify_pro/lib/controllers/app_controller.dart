import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/local_db.dart';
import '../models/task_model.dart';
import '../services/supabase_service.dart';

class AppController extends GetxController {
  final LocalDb _db = LocalDb.instance;

  final tasks = <TaskModel>[].obs;
  final ready = false.obs;
  final isLocked = false.obs;
  final themeMode = ThemeMode.system.obs;
  final searchQuery = ''.obs;
  final filter = TaskFilter.all.obs;
  final pinEnabled = false.obs;
  final pinHash = ''.obs;
  final supabaseService = SupabaseService.instance;
  @override
  void onInit() {
    super.onInit();
    initApp();
  }

  Future<void> initApp() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      final themeIndex = prefs.getInt('themeMode') ?? ThemeMode.system.index;
      final safeIndex = themeIndex.clamp(0, ThemeMode.values.length - 1);
      themeMode.value = ThemeMode.values[safeIndex];

      pinEnabled.value = prefs.getBool('pinEnabled') ?? false;
      pinHash.value = prefs.getString('pinHash') ?? '';

      final savedTasks = await _db.fetchTasks();
      tasks.assignAll(savedTasks);

      isLocked.value = pinEnabled.value;
    } catch (e) {
      debugPrint('initApp failed: $e');
      tasks.clear();
      themeMode.value = ThemeMode.system;
      pinEnabled.value = false;
      pinHash.value = '';
      isLocked.value = false;
    } finally {
      ready.value = true;
    }
  }

  String _hashPin(String pin) {
    return sha256.convert(utf8.encode(pin.trim())).toString();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode.value = mode;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('themeMode', mode.index);
  }

  Future<bool> unlock(String pin) async {
    final valid = pinHash.value == _hashPin(pin);
    if (valid) {
      isLocked.value = false;
      Get.snackbar('Unlocked', 'Welcome back');
    }
    return valid;
  }
  Future<bool> setPin(String pin) async {
    final clean = pin.trim();

    if (clean.length < 4) {
      return false;
    }

    final hash = _hashPin(clean);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('pinHash', hash);
    await prefs.setBool('pinEnabled', true);

    pinEnabled.value = true;
    pinHash.value = hash;

    return true;
  }

  Future<bool> changePin({
    required String currentPin,
    required String newPin,
  }) async {
    if (pinHash.value != _hashPin(currentPin.trim())) {
      return false;
    }

    return await setPin(newPin);
  }

  Future<void> disablePin() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('pinHash');
    await prefs.setBool('pinEnabled', false);

    pinEnabled.value = false;
    pinHash.value = '';
    isLocked.value = false;
  }

  void lockNow() {
    if (pinEnabled.value) {
      isLocked.value = true;
    }
  }

  void setSearch(String value) {
    searchQuery.value = value;
  }

  void setFilter(TaskFilter value) {
    filter.value = value;
  }

  List<TaskModel> get visibleTasks {
    final q = searchQuery.value.trim().toLowerCase();

    final filtered = tasks.where((task) {
      final matchesSearch = q.isEmpty ||
          task.title.toLowerCase().contains(q) ||
          task.note.toLowerCase().contains(q) ||
          task.category.toLowerCase().contains(q);

      final matchesFilter = switch (filter.value) {
        TaskFilter.all => true,
        TaskFilter.pending => !task.isDone,
        TaskFilter.completed => task.isDone,
        TaskFilter.highPriority => task.priority == TaskPriority.high,
      };

      return matchesSearch && matchesFilter;
    }).toList();

    filtered.sort((a, b) {
      if (a.isDone != b.isDone) {
        return a.isDone ? 1 : -1;
      }
      return b.updatedAt.compareTo(a.updatedAt);
    });

    return filtered;
  }

  int get totalTasks => tasks.length;
  int get completedTasks => tasks.where((t) => t.isDone).length;
  int get pendingTasks => totalTasks - completedTasks;
  double get progress => totalTasks == 0 ? 0 : completedTasks / totalTasks;

  Future<void> addTask(TaskModel task) async {
    await _db.upsertTask(task);
    tasks.insert(0, task);

    await supabaseService.addTask(task); // 🔥 cloud sync
  }

  Future<void> updateTask(TaskModel task) async {
    await _db.upsertTask(task);

    final index = tasks.indexWhere((t) => t.id == task.id);
    if (index != -1) {
      tasks[index] = task;
      tasks.refresh();
    }

    await _db.upsertTask(task);
  }

  Future<void> toggleTask(String id) async {
    final index = tasks.indexWhere((t) => t.id == id);
    if (index == -1) return;

    final updated = tasks[index].copyWith(
      isDone: !tasks[index].isDone,
      updatedAt: DateTime.now(),
    );

    tasks[index] = updated;
    await _db.upsertTask(updated);
  }

  Future<void> deleteTask(String id) async {
    tasks.removeWhere((t) => t.id == id);
    await supabaseService.deleteTask(id);  }

  Future<void> clearCompleted() async {
    tasks.removeWhere((t) => t.isDone);
    await _db.clearCompleted();
  }

  Future<void> clearEverything() async {
    await _db.clearAll();

    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    tasks.clear();
    searchQuery.value = '';
    filter.value = TaskFilter.all;
    themeMode.value = ThemeMode.system;
    pinEnabled.value = false;
    pinHash.value = '';
    isLocked.value = false;

    await prefs.setInt('themeMode', ThemeMode.system.index);
    Get.snackbar('Reset complete', 'All local app data has been cleared');
  }
}