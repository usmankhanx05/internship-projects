import 'package:get/get.dart';
import '../app/app_config.dart';
import '../data/local_db.dart';
import '../models/task_model.dart';
import '../services/cloud_sync_service.dart';

class TaskController extends GetxController {
  final LocalDb _db = LocalDb.instance;
  final CloudSyncService _cloud = CloudSyncService.instance;

  final tasks = <TaskModel>[].obs;
  final isLoading = true.obs;
  final filter = TaskFilter.all.obs;
  final searchQuery = ''.obs;

  @override
  void onInit() {
    super.onInit();
    loadTasks();
  }

  Future<void> loadTasks() async {
    isLoading.value = true;
    final data = await _db.fetchTasks();
    tasks.assignAll(data);
    tasks.refresh();
    isLoading.value = false;
  }

  void setSearch(String value) {
    searchQuery.value = value;
  }

  void setFilter(TaskFilter value) {
    filter.value = value;
  }

  List<TaskModel> get visibleTasks {
    final q = searchQuery.value.trim().toLowerCase();

    final filtered = tasks.where((task) {
      final matchesSearch = q.isEmpty ||
          task.title.toLowerCase().contains(q) ||
          task.note.toLowerCase().contains(q) ||
          task.category.toLowerCase().contains(q);

      final matchesFilter = switch (filter.value) {
        TaskFilter.all => true,
        TaskFilter.pending => !task.isDone,
        TaskFilter.completed => task.isDone,
        TaskFilter.highPriority => task.priority == TaskPriority.high,
      };

      return matchesSearch && matchesFilter;
    }).toList();

    filtered.sort((a, b) {
      if (a.isDone != b.isDone) {
        return a.isDone ? 1 : -1;
      }
      return b.updatedAt.compareTo(a.updatedAt);
    });

    return filtered;
  }

  int get totalTasks => tasks.length;
  int get completedTasks => tasks.where((t) => t.isDone).length;
  int get pendingTasks => totalTasks - completedTasks;
  double get progress => totalTasks == 0 ? 0 : completedTasks / totalTasks;

  Future<void> addTask(TaskModel task) async {
    await _db.upsertTask(task);
    tasks.insert(0, task);
    await _maybeSync();
  }

  Future<void> updateTask(TaskModel task) async {
    // Update in database
    await _db.upsertTask(task);

    // Update in local list (VERY IMPORTANT)
    final index = tasks.indexWhere((t) => t.id == task.id);

    if (index != -1) {
      tasks[index] = task;
      tasks.refresh(); // force UI update
    }

    // Reload everything (extra safety)
    await loadTasks();
  }

  Future<void> toggleTask(String id) async {
    final index = tasks.indexWhere((t) => t.id == id);
    if (index == -1) return;

    final updated = tasks[index].copyWith(
      isDone: !tasks[index].isDone,
      updatedAt: DateTime.now(),
    );

    tasks[index] = updated;
    await _db.upsertTask(updated);
    await _maybeSync();
  }

  Future<void> deleteTask(String id) async {
    tasks.removeWhere((t) => t.id == id);
    await _db.deleteTask(id);
    await _maybeSync();
  }

  Future<void> clearCompleted() async {
    tasks.removeWhere((t) => t.isDone);
    await _db.clearCompleted();
    await _maybeSync();
  }

  Future<void> syncNow() async {
    if (!AppConfig.enableSupabaseSync) {
      Get.snackbar('Cloud sync off', 'Enable Supabase later when you add keys.');
      return;
    }

    await _cloud.initialize();
    final remote = await _cloud.pullTasks();

    if (remote.isEmpty) {
      await _cloud.pushTasks(tasks.toList());
      Get.snackbar('Synced', 'Local tasks uploaded to Supabase.');
      return;
    }

    final merged = <String, TaskModel>{};

    for (final task in [...tasks, ...remote]) {
      final existing = merged[task.id];
      if (existing == null || task.updatedAt.isAfter(existing.updatedAt)) {
        merged[task.id] = task;
      }
    }

    final combined = merged.values.toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));

    tasks.assignAll(combined);
    for (final item in combined) {
      await _db.upsertTask(item);
    }

    Get.snackbar('Synced', 'Local and cloud tasks merged.');
  }

  Future<void> _maybeSync() async {
    if (!AppConfig.enableSupabaseSync) return;
    await _cloud.initialize();
    await _cloud.pushTasks(tasks.toList());
  }
}