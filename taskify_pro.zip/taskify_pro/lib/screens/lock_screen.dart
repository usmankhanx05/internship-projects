import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/app_controller.dart';

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> {
  final AppController c = Get.find<AppController>();
  final TextEditingController pinController = TextEditingController();
  bool wrongPin = false;

  @override
  void dispose() {
    pinController.dispose();
    super.dispose();
  }

  Future<void> _unlock() async {
    final ok = await c.unlock(pinController.text);
    if (!ok) {
      setState(() => wrongPin = true);
      Get.snackbar('Wrong PIN', 'Please try again');
      return;
    }

    setState(() => wrongPin = false);
    pinController.clear();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    final topColor = isDark ? const Color(0xFF0F9D9A) : const Color(0xFF0F9D9A);
    final bottomColor = isDark ? const Color(0xFF0E1518) : const Color(0xFFF5F8FB);
    final cardColor = isDark ? const Color(0xFF162126) : Colors.white;
    final iconBg = isDark ? const Color(0xFF123836) : const Color(0xFFEAF8F6);
    final iconColor = const Color(0xFF0F9D9A);
    final mainTextColor = isDark ? Colors.white : Theme.of(context).colorScheme.onSurface;
    final subTextColor = isDark
        ? Colors.white70
        : Theme.of(context).colorScheme.onSurfaceVariant;
    final fieldFill = isDark ? const Color(0xFF101A1D) : const Color(0xFFF6F8FB);
    final fieldTextColor = isDark ? Colors.white : Colors.black87;
    final hintColor = isDark ? Colors.white54 : Colors.black38;

    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [topColor, bottomColor],
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Card(
              color: cardColor,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      height: 76,
                      width: 76,
                      decoration: BoxDecoration(
                        color: iconBg,
                        borderRadius: BorderRadius.circular(24),
                      ),
                      child: const Icon(
                        Icons.lock_rounded,
                        size: 38,
                        color: Color(0xFF0F9D9A),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      'Taskify Locked',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.3,
                        color: mainTextColor,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Enter your PIN to continue.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: subTextColor,
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextField(
                      controller: pinController,
                      keyboardType: TextInputType.number,
                      maxLength: 8,
                      obscureText: true,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 6,
                        color: fieldTextColor,
                      ),
                      decoration: InputDecoration(
                        hintText: '••••',
                        hintStyle: TextStyle(color: hintColor),
                        counterText: '',
                        filled: true,
                        fillColor: fieldFill,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: BorderSide.none,
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: const BorderSide(color: Color(0xFF0F9D9A), width: 1.5),
                        ),
                      ),
                      onSubmitted: (_) => _unlock(),
                    ),
                    if (wrongPin) ...[
                      const SizedBox(height: 8),
                      const Text(
                        'Incorrect PIN',
                        style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w600),
                      ),
                    ],
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      height: 54,
                      child: FilledButton(
                        onPressed: _unlock,
                        child: const Text('Unlock'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}