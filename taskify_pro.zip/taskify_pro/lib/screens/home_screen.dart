import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:url_launcher/url_launcher.dart';

import '../app/app_config.dart';
import '../controllers/app_controller.dart';
import '../models/task_model.dart';
import '../services/ad_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final AppController c = Get.find<AppController>();
  BannerAd? _bannerAd;

  final List<String> _categories = const [
    'General',
    'Work',
    'Study',
    'Personal',
    'Shopping',
    'Health',
  ];

  @override
  void initState() {
    super.initState();
    _loadBanner();
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  Future<void> _loadBanner() async {
    final adUnitId = AdService.instance.bannerAdUnitId;
    if (adUnitId.isEmpty) return;

    final banner = BannerAd(
      adUnitId: adUnitId,
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          if (!mounted) return;
          setState(() => _bannerAd = ad as BannerAd);
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
        },
      ),
    );

    await banner.load();
  }

  String _formatDate(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  Future<void> _openTaskForm({TaskModel? existing}) async {
    final result = await Navigator.push<TaskModel>(
      context,
      MaterialPageRoute(
        builder: (_) => TaskFormPage(
          existing: existing,
          categories: _categories,
        ),
      ),
    );

    if (result == null || !mounted) return;

    if (existing == null) {
      await c.addTask(result);
      Get.snackbar('Saved', 'Task added successfully');
    } else {
      await c.updateTask(result);
      Get.snackbar('Updated', 'Task updated successfully');
    }
  }

  Future<void> _openPrivacyPolicy() async {
    final uri = Uri.parse('https://tarteebprivacy.com/privacy-policy/');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      Get.snackbar('Error', 'Could not open privacy policy');
    }
  }

  Future<void> _confirmClearEverything() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Clear all app data?'),
          content: const Text(
            'This will delete all tasks and reset the app settings, including PIN and theme.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext, rootNavigator: true).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(dialogContext, rootNavigator: true).pop(true),
              child: const Text('Clear'),
            ),
          ],
        );
      },
    );

    if (ok == true) {
      await c.clearEverything();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('All app data cleared')),
      );
    }
  }

  Future<void> _showPinDialog() async {
    final currentCtrl = TextEditingController();
    final newCtrl = TextEditingController();
    final confirmCtrl = TextEditingController();

    final isChange = c.pinEnabled.value;

    final saved = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text(isChange ? 'Change PIN' : 'Set PIN'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (isChange)
                  TextField(
                    controller: currentCtrl,
                    keyboardType: TextInputType.number,
                    obscureText: true,
                    maxLength: 8,
                    decoration: const InputDecoration(
                      labelText: 'Current PIN',
                      counterText: '',
                    ),
                  ),
                TextField(
                  controller: newCtrl,
                  keyboardType: TextInputType.number,
                  obscureText: true,
                  maxLength: 8,
                  decoration: const InputDecoration(
                    labelText: 'New PIN',
                    counterText: '',
                  ),
                ),
                TextField(
                  controller: confirmCtrl,
                  keyboardType: TextInputType.number,
                  obscureText: true,
                  maxLength: 8,
                  decoration: const InputDecoration(
                    labelText: 'Confirm PIN',
                    counterText: '',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(dialogContext, false);
              },
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () async {
                final newPin = newCtrl.text.trim();
                final confirmPin = confirmCtrl.text.trim();

                if (newPin.length < 4) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(
                    const SnackBar(content: Text('PIN must be at least 4 digits')),
                  );
                  return;
                }

                if (newPin != confirmPin) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(
                    const SnackBar(content: Text('PINs do not match')),
                  );
                  return;
                }

                bool ok;

                if (isChange) {
                  ok = await c.changePin(
                    currentPin: currentCtrl.text.trim(),
                    newPin: newPin,
                  );
                } else {
                  ok = await c.setPin(newPin);
                }

                if (!ok) {
                  ScaffoldMessenger.of(dialogContext).showSnackBar(
                    const SnackBar(content: Text('Failed to save PIN')),
                  );
                  return;
                }

                Navigator.pop(dialogContext, true);
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );

    await Future.delayed(const Duration(milliseconds: 300));

    if (saved == true && mounted) {
      c.lockNow();

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('PIN saved successfully')),
      );
    }

    currentCtrl.dispose();
    newCtrl.dispose();
    confirmCtrl.dispose();
  }

  Widget _statCard(String title, String value, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.12),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withOpacity(0.14)),
      ),
      child: Row(
        children: [
          Container(
            height: 37,
            width: 37,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.16),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Icon(icon, color: Colors.white),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.4,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _taskChip(BuildContext context, String text, bool selected, VoidCallback onTap) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.only(right: 10),
      child: ChoiceChip(
        label: Text(text),
        selected: selected,
        onSelected: (_) => onTap(),
        labelStyle: TextStyle(
          fontWeight: FontWeight.w600,
          color: selected
              ? Colors.white
              : (isDark ? Colors.white70 : const Color(0xFF1A2B3C)),
        ),
        selectedColor: const Color(0xFF0F9D9A),
        backgroundColor: isDark ? const Color(0xFF162126) : Colors.white,
        side: BorderSide(
          color: isDark ? const Color(0xFF2B373D) : const Color(0xFFE3EAF2),
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  Widget _taskTile(BuildContext context, TaskModel task) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final mainTextColor =
    isDark ? Colors.white : const Color(0xFF102033);
    final subTextColor =
    isDark ? Colors.white70 : const Color(0xFF4A6175);
    final categoryTextColor =
    isDark ? Colors.white70 : const Color(0xFF4A6175);
    final categoryBg = isDark ? const Color(0xFF1A2328) : const Color(0xFFF1F7FB);
    final dueBg = isDark ? const Color(0xFF123836) : const Color(0xFFEAF8F6);

    return Dismissible(
      key: ValueKey(task.id),
      direction: DismissDirection.endToStart,
      background: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.only(right: 18),
        decoration: BoxDecoration(
          color: const Color(0xFFFF6B6B),
          borderRadius: BorderRadius.circular(22),
        ),
        alignment: Alignment.centerRight,
        child: const Icon(Icons.delete_rounded, color: Colors.white),
      ),
      onDismissed: (_) => c.deleteTask(task.id),
      child: Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: () => c.toggleTask(task.id),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                AnimatedContainer(
                  duration: const Duration(milliseconds: 180),
                  height: 28,
                  width: 28,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: task.isDone ? const Color(0xFF0F9D9A) : Colors.transparent,
                    border: Border.all(
                      color: task.isDone ? const Color(0xFF0F9D9A) : const Color(0xFFC9D6E2),
                      width: 2,
                    ),
                  ),
                  child: task.isDone
                      ? const Icon(Icons.check_rounded, size: 18, color: Colors.white)
                      : null,
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        task.title,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w800,
                          color: task.isDone ? subTextColor : mainTextColor,
                          decoration:
                          task.isDone ? TextDecoration.lineThrough : TextDecoration.none,
                        ),
                      ),
                      if (task.note.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(
                          task.note,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: subTextColor,
                            height: 1.35,
                          ),
                        ),
                      ],
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: task.priority.color.withOpacity(isDark ? 0.18 : 0.12),
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(task.priority.icon, size: 16, color: task.priority.color),
                                const SizedBox(width: 4),
                                Text(
                                  task.priority.label,
                                  style: TextStyle(
                                    color: task.priority.color,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: categoryBg,
                              borderRadius: BorderRadius.circular(999),
                            ),
                            child: Text(
                              task.category,
                              style: TextStyle(
                                color: categoryTextColor,
                                fontWeight: FontWeight.w700,
                                fontSize: 12,
                              ),
                            ),
                          ),
                          if (task.dueDate != null)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: dueBg,
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                _formatDate(task.dueDate!),
                                style: const TextStyle(
                                  color: Color(0xFF0F9D9A),
                                  fontWeight: FontWeight.w700,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
                Column(
                  children: [
                    IconButton(
                      onPressed: () => _openTaskForm(existing: task),
                      icon: const Icon(Icons.edit_rounded),
                    ),
                    IconButton(
                      onPressed: () => c.deleteTask(task.id),
                      icon: const Icon(Icons.delete_outline_rounded),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDrawer(BuildContext context) {
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(
                color: Color(0xFF0F9D9A),
              ),
              child: SizedBox(
                width: double.infinity,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    CircleAvatar(
                      radius: 26,
                      backgroundColor: Colors.white24,
                      child: Icon(Icons.check_circle_outline_rounded, color: Colors.white, size: 30),
                    ),
                    SizedBox(height: 14),
                    Text(
                      'Tarteeb',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      'Offline-first productivity app',
                      style: TextStyle(color: Colors.white70),
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(8, 6, 8, 6),
                    child: Text(
                      'App lock',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                  Obx(
                        () => ListTile(
                      leading: const Icon(Icons.lock_outline_rounded),
                      title: Text(c.pinEnabled.value ? 'Change PIN' : 'Set PIN'),
                      onTap: () async {
                        Navigator.pop(context);
                        await Future.delayed(const Duration(milliseconds: 300));
                        if (!mounted) return;
                        await _showPinDialog();
                      },
                    ),
                  ),
                  Obx(
                        () => ListTile(
                      leading: const Icon(Icons.lock_reset_rounded),
                      title: const Text('Lock now'),
                      enabled: c.pinEnabled.value,
                      onTap: () {
                        Navigator.pop(context);
                        c.lockNow();
                      },
                    ),
                  ),
                  Obx(
                        () => ListTile(
                      leading: const Icon(Icons.delete_forever_rounded),
                      title: const Text('Remove PIN'),
                      enabled: c.pinEnabled.value,
                      onTap: () async {
                        Navigator.pop(context);
                        await Future.delayed(const Duration(milliseconds: 150));
                        if (!mounted) return;
                        await c.disablePin();
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('PIN removed')),
                        );
                      },
                    ),
                  ),
                  const Divider(height: 28),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8),
                    child: Text(
                      'Theme',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                  Obx(
                        () => RadioListTile<ThemeMode>(
                      value: ThemeMode.system,
                      groupValue: c.themeMode.value,
                      title: const Text('System'),
                      onChanged: (value) {
                        if (value != null) c.setThemeMode(value);
                      },
                    ),
                  ),
                  Obx(
                        () => RadioListTile<ThemeMode>(
                      value: ThemeMode.light,
                      groupValue: c.themeMode.value,
                      title: const Text('Light'),
                      onChanged: (value) {
                        if (value != null) c.setThemeMode(value);
                      },
                    ),
                  ),
                  Obx(
                        () => RadioListTile<ThemeMode>(
                      value: ThemeMode.dark,
                      groupValue: c.themeMode.value,
                      title: const Text('Dark'),
                      onChanged: (value) {
                        if (value != null) c.setThemeMode(value);
                      },
                    ),
                  ),
                  const Divider(height: 28),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8),
                    child: Text(
                      'Data',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.cleaning_services_rounded),
                    title: const Text('Clear completed'),
                    onTap: () async {
                      Navigator.pop(context);
                      await c.clearCompleted();
                      Get.snackbar('Done', 'Completed tasks removed');
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.restore_rounded),
                    title: const Text('Clear whole app'),
                    onTap: () async {
                      Navigator.pop(context);
                      await _confirmClearEverything();
                    },
                  ),
                  const Divider(height: 28),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8),
                    child: Text(
                      'About',
                      style: TextStyle(fontWeight: FontWeight.w800),
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.info_outline_rounded),
                    title: const Text('About Tarteeb'),
                    onTap: () {
                      Navigator.pop(context);
                      showDialog(
                        context: context,
                        builder: (dialogContext) => AlertDialog(
                          title: const Text('About Tarteeb'),
                          content: const Text(
                            'Tarteeb is an elegant offline-first productivity companion built to help you plan clearly, stay focused, and complete your tasks with confidence.',
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(dialogContext),
                              child: const Text('Close'),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.privacy_tip_outlined),
                    title: const Text('Privacy & Policy'),
                    onTap: () async {
                      Navigator.pop(context);
                      await _openPrivacyPolicy();
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBanner(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (_bannerAd == null) return const SizedBox.shrink();

    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 6),
                child: Text(
                  'Sponsored',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: isDark ? Colors.white70 : Colors.black54,
                  ),
                ),
              ),
            ),
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Container(
                color: Colors.white,
                alignment: Alignment.center,
                width: double.infinity,
                height: _bannerAd!.size.height.toDouble(),
                child: AdWidget(ad: _bannerAd!),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: _buildDrawer(context),
      appBar: AppBar(
        title: const Text('Tarteeb'),
        actions: [
          IconButton(
            onPressed: c.lockNow,
            tooltip: 'Lock app',
            icon: const Icon(Icons.lock_outline_rounded),
          ),
          IconButton(
            onPressed: () => c.clearCompleted(),
            tooltip: 'Clear completed',
            icon: const Icon(Icons.delete_sweep_rounded),
          ),
          const SizedBox(width: 4),
        ],
      ),
      bottomNavigationBar: _buildBanner(context),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF0F9D9A),
        foregroundColor: Colors.white,
        onPressed: () => _openTaskForm(),
        child: const Icon(Icons.add_rounded),
      ),
      body: Obx(() {
        final tasks = c.visibleTasks;
        final progressPercent = (c.progress * 100).round();
        final isDark = Theme.of(context).brightness == Brightness.dark;
        final bodyMainText = isDark ? Colors.white : const Color(0xFF102033);
        final bodySubText = isDark ? Colors.white70 : const Color(0xFF4A6175);

        return CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: Container(
                width: double.infinity,
                margin: const EdgeInsets.fromLTRB(16, 14, 16, 12),
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F9D9A),
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF0F9D9A).withOpacity(0.18),
                      blurRadius: 22,
                      offset: const Offset(0, 12),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          height: 54,
                          width: 54,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.16),
                            borderRadius: BorderRadius.circular(18),
                          ),
                          child: const Icon(
                            Icons.check_circle_outline_rounded,
                            color: Colors.white,
                          ),
                        ),
                        const SizedBox(width: 12),
                        const Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Stay focused. Finish stronger.',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: -0.3,
                                ),
                              ),
                              SizedBox(height: 4),
                              Text(
                                'Offline-first, fast, and distraction-free.',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 13,
                                  height: 1.3,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    LayoutBuilder(
                      builder: (context, constraints) {
                        if (constraints.maxWidth < 360) {
                          return Wrap(
                            spacing: 10,
                            runSpacing: 10,
                            children: [
                              SizedBox(
                                width: 100,
                                child: _statCard('Total', '${c.totalTasks}', Icons.list_alt_rounded),
                              ),
                              SizedBox(
                                width: 100,
                                child: _statCard('Done', '${c.completedTasks}', Icons.verified_rounded),
                              ),
                              SizedBox(
                                width: 100,
                                child: _statCard('Left', '${c.pendingTasks}', Icons.schedule_rounded),
                              ),
                            ],
                          );
                        }

                        return Row(
                          children: [
                            Expanded(
                              child: _statCard('Total', '${c.totalTasks}', Icons.list_alt_rounded),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _statCard('Done', '${c.completedTasks}', Icons.verified_rounded),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: _statCard('Left', '${c.pendingTasks}', Icons.schedule_rounded),
                            ),
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 14),
                    Text(
                      'Progress',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.92),
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(99),
                      child: LinearProgressIndicator(
                        minHeight: 10,
                        value: c.progress,
                        backgroundColor: Colors.white.withOpacity(0.22),
                        valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '$progressPercent% completed today',
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
                child: TextField(
                  onChanged: c.setSearch,
                  style: TextStyle(color: bodyMainText),
                  decoration: InputDecoration(
                    hintText: 'Search tasks, notes, or category',
                    hintStyle: TextStyle(color: bodySubText),
                    prefixIcon: Icon(Icons.search_rounded, color: bodySubText),
                    suffixIcon: Obx(() {
                      if (c.searchQuery.value.isEmpty) return const SizedBox.shrink();
                      return IconButton(
                        onPressed: () => c.setSearch(''),
                        icon: Icon(Icons.close_rounded, color: bodySubText),
                      );
                    }),
                    filled: true,
                    fillColor: isDark ? const Color(0xFF162126) : Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: SizedBox(
                height: 48,
                child: Obx(() {
                  return ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    scrollDirection: Axis.horizontal,
                    children: [
                      _taskChip(context, TaskFilter.all.label, c.filter.value == TaskFilter.all,
                              () => c.setFilter(TaskFilter.all)),
                      _taskChip(context, TaskFilter.pending.label, c.filter.value == TaskFilter.pending,
                              () => c.setFilter(TaskFilter.pending)),
                      _taskChip(context, TaskFilter.completed.label, c.filter.value == TaskFilter.completed,
                              () => c.setFilter(TaskFilter.completed)),
                      _taskChip(context, TaskFilter.highPriority.label, c.filter.value == TaskFilter.highPriority,
                              () => c.setFilter(TaskFilter.highPriority)),
                    ],
                  );
                }),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Your tasks',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w800,
                        letterSpacing: -0.3,
                        color: bodyMainText,
                      ),
                    ),
                    Text(
                      '${tasks.length} items',
                      style: TextStyle(
                        color: bodySubText,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            if (tasks.isEmpty)
              SliverFillRemaining(
                hasScrollBody: false,
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          height: 92,
                          width: 92,
                          decoration: BoxDecoration(
                            color: const Color(0xFFEAF8F6),
                            borderRadius: BorderRadius.circular(28),
                          ),
                          child: const Icon(Icons.inbox_rounded,
                              size: 42, color: Color(0xFF0F9D9A)),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'No tasks found',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w800,
                            color: bodyMainText,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Create a task using the + button below.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: bodySubText,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              )
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                        (context, index) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _taskTile(context, tasks[index]),
                    ),
                    childCount: tasks.length,
                  ),
                ),
              ),
            const SliverToBoxAdapter(child: SizedBox(height: 100)),
          ],
        );
      }),
    );
  }
}

class TaskFormPage extends StatefulWidget {
  final TaskModel? existing;
  final List<String> categories;

  const TaskFormPage({
    super.key,
    required this.existing,
    required this.categories,
  });

  @override
  State<TaskFormPage> createState() => _TaskFormPageState();
}

class _TaskFormPageState extends State<TaskFormPage> {
  late final TextEditingController titleCtrl;
  late final TextEditingController noteCtrl;

  late String category;
  late TaskPriority priority;
  DateTime? dueDate;

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    titleCtrl = TextEditingController(text: widget.existing?.title ?? '');
    noteCtrl = TextEditingController(text: widget.existing?.note ?? '');
    category = widget.existing?.category ?? 'General';
    priority = widget.existing?.priority ?? TaskPriority.medium;
    dueDate = widget.existing?.dueDate;
  }

  @override
  void dispose() {
    titleCtrl.dispose();
    noteCtrl.dispose();
    super.dispose();
  }

  String _formatDate(DateTime date) {
    return '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.existing != null;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final fillColor = isDark ? const Color(0xFF101A1D) : const Color(0xFFF6F9FC);
    final mainTextColor = isDark ? Colors.white : const Color(0xFF102033);
    final subTextColor = isDark ? Colors.white70 : const Color(0xFF4A6175);

    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Edit Task' : 'Create Task'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isEdit ? 'Update your task details' : 'Add a new task',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -0.3,
                    color: mainTextColor,
                  ),
                ),
                const SizedBox(height: 18),
                TextFormField(
                  controller: titleCtrl,
                  style: TextStyle(color: mainTextColor),
                  decoration: InputDecoration(
                    labelText: 'Task title',
                    labelStyle: TextStyle(color: subTextColor),
                    filled: true,
                    fillColor: fillColor,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Task title cannot be empty';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: noteCtrl,
                  keyboardType: TextInputType.multiline,
                  textInputAction: TextInputAction.newline,
                  minLines: 3,
                  maxLines: null,
                  style: TextStyle(color: mainTextColor),
                  decoration: InputDecoration(
                    labelText: 'Description',
                    labelStyle: TextStyle(color: subTextColor),
                    filled: true,
                    fillColor: fillColor,
                    alignLabelWithHint: true,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: category,
                  isExpanded: true,
                  style: TextStyle(color: mainTextColor),
                  decoration: InputDecoration(
                    labelText: 'Category',
                    labelStyle: TextStyle(color: subTextColor),
                    filled: true,
                    fillColor: fillColor,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  items: widget.categories
                      .map(
                        (item) => DropdownMenuItem(
                      value: item,
                      child: Text(item),
                    ),
                  )
                      .toList(),
                  onChanged: (value) {
                    if (value == null) return;
                    setState(() => category = value);
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<TaskPriority>(
                  value: priority,
                  isExpanded: true,
                  style: TextStyle(color: mainTextColor),
                  decoration: InputDecoration(
                    labelText: 'Priority',
                    labelStyle: TextStyle(color: subTextColor),
                    filled: true,
                    fillColor: fillColor,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  items: TaskPriority.values
                      .map(
                        (p) => DropdownMenuItem(
                      value: p,
                      child: Text(p.label),
                    ),
                  )
                      .toList(),
                  onChanged: (value) {
                    if (value == null) return;
                    setState(() => priority = value);
                  },
                ),
                const SizedBox(height: 12),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(
                    'Due date',
                    style: TextStyle(color: mainTextColor),
                  ),
                  subtitle: Text(
                    dueDate == null ? 'No due date' : _formatDate(dueDate!),
                    style: TextStyle(color: subTextColor),
                  ),
                  trailing: const Icon(Icons.calendar_month_rounded),
                  onTap: () async {
                    final picked = await showDatePicker(
                      context: context,
                      firstDate: DateTime.now().subtract(const Duration(days: 1)),
                      lastDate: DateTime.now().add(const Duration(days: 3650)),
                      initialDate: dueDate ?? DateTime.now(),
                    );
                    if (picked != null) {
                      setState(() => dueDate = picked);
                    }
                  },
                ),
                const SizedBox(height: 18),
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: FilledButton(
                    onPressed: () {
                      if (!_formKey.currentState!.validate()) return;

                      final task = TaskModel(
                        id: widget.existing?.id ??
                            DateTime.now().microsecondsSinceEpoch.toString(),
                        title: titleCtrl.text.trim(),
                        note: noteCtrl.text.trim(),
                        category: category,
                        priority: priority,
                        isDone: widget.existing?.isDone ?? false,
                        createdAt: widget.existing?.createdAt,
                        updatedAt: DateTime.now(),
                        dueDate: dueDate,
                      );

                      Navigator.pop(context, task);
                    },
                    child: Text(isEdit ? 'Update Task' : 'Save Task'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}