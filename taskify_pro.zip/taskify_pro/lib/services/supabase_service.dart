import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/task_model.dart';

class SupabaseService {
  SupabaseService._();
  static final SupabaseService instance = SupabaseService._();

  SupabaseClient get client => Supabase.instance.client;

  Future<void> addTask(TaskModel task) async {
    await client.from('tasks').insert(task.toMap());
  }

  Future<List<TaskModel>> getTasks() async {
    final data = await client.from('tasks').select();
    return (data as List).map((e) => TaskModel.fromMap(Map<String, dynamic>.from(e))).toList();
  }

  Future<void> updateTask(TaskModel task) async {
    await client.from('tasks').update(task.toMap()).eq('id', task.id);
  }

  Future<void> deleteTask(String id) async {
    await client.from('tasks').delete().eq('id', id);
  }
}