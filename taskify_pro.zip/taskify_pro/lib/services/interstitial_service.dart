import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../app/app_config.dart';

class InterstitialService {
  InterstitialAd? _ad;

  void loadAd() {
    InterstitialAd.load(
      adUnitId: AppConfig.useTestAds
          ? AppConfig.testInterstitial
          : AppConfig.realInterstitial,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) {
          _ad = ad;
        },
        onAdFailedToLoad: (error) {
          _ad = null;
        },
      ),
    );
  }

  void showAd() {
    if (_ad != null) {
      _ad!.show();
      _ad = null;
      loadAd(); // preload next
    }
  }
}