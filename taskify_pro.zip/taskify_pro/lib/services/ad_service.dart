import 'dart:io';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../app/app_config.dart';

class AdService {
  AdService._();
  static final AdService instance = AdService._();

  Future<void> initialize() async {
    await MobileAds.instance.initialize();
  }

  // 🔥 Banner Ad ID
  String get bannerAdUnitId {
    if (AppConfig.useTestAds) {
      return AppConfig.testBanner;
    }

    if (Platform.isAndroid) {
      return AppConfig.realBanner;
    }

    return AppConfig.realBanner;
  }

  // 🔥 Interstitial Ad ID
  String get interstitialAdUnitId {
    if (AppConfig.useTestAds) {
      return AppConfig.testInterstitial;
    }

    if (Platform.isAndroid) {
      return AppConfig.realInterstitial;
    }

    return AppConfig.realInterstitial;
  }
}