
import 'package:supabase_flutter/supabase_flutter.dart';
import '../app/app_config.dart';
import '../models/task_model.dart';

class CloudSyncService {
  CloudSyncService._();
  static final CloudSyncService instance = CloudSyncService._();

  bool _initialized = false;

  bool get isEnabled =>
      AppConfig.enableSupabaseSync &&
          AppConfig.supabaseUrl != 'https://xgpcyxuahtpoerjletuz.supabase.co' &&
          AppConfig.supabaseAnonKey != 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhncGN5eHVhaHRwb2VyamxldHV6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ0NTcwMzUsImV4cCI6MjA5MDAzMzAzNX0.zsXvYWD8Xv_CMA_-g9cb1IkKophRSj6xmkFgVDkhn6Y' &&
          AppConfig.supabaseUrl.startsWith('https://') &&
          AppConfig.supabaseAnonKey.isNotEmpty;

  Future<void> initialize() async {
    if (!isEnabled || _initialized) return;

    await Supabase.initialize(
      url: AppConfig.supabaseUrl,
      anonKey: AppConfig.supabaseAnonKey,
    );
    _initialized = true;
  }

  Future<void> pushTasks(List<TaskModel> tasks) async {
    if (!isEnabled || !_initialized) return;

    await Supabase.instance.client
        .from('tasks')
        .upsert(tasks.map((e) => e.toMap()).toList(), onConflict: 'id');
  }

  Future<List<TaskModel>> pullTasks() async {
    if (!isEnabled || !_initialized) return [];

    final result = await Supabase.instance.client.from('tasks').select();
    final data = result as List<dynamic>;

    return data
        .map((e) => TaskModel.fromMap(Map<String, dynamic>.from(e as Map)))
        .toList();
  }
}