import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/task_model.dart';

class LocalDb {
  LocalDb._();
  static final LocalDb instance = LocalDb._();

  static const _dbName = 'taskify.db';
  static const _dbVersion = 1;
  static const _table = 'tasks';

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _init();
    return _db!;
  }

  Future<Database> _init() async {
    final dbPath = await getDatabasesPath();
    final pathToDb = join(dbPath, _dbName);

    return openDatabase(
      pathToDb,
      version: _dbVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE $_table (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            note TEXT NOT NULL,
            category TEXT NOT NULL,
            priority INTEGER NOT NULL,
            isDone INTEGER NOT NULL,
            createdAt TEXT NOT NULL,
            updatedAt TEXT NOT NULL,
            dueDate TEXT
          )
        ''');
      },
    );
  }

  Future<List<TaskModel>> fetchTasks() async {
    final db = await database;
    final rows = await db.query(
      _table,
      orderBy: 'isDone ASC, updatedAt DESC',
    );
    return rows.map(TaskModel.fromMap).toList();
  }

  Future<void> upsertTask(TaskModel task) async {
    final db = await database;
    await db.insert(
      _table,
      task.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> deleteTask(String id) async {
    final db = await database;
    await db.delete(_table, where: 'id = ?', whereArgs: [id]);
  }

  Future<void> clearCompleted() async {
    final db = await database;
    await db.delete(_table, where: 'isDone = ?', whereArgs: [1]);
  }

  Future<void> clearAll() async {
    final db = await database;
    await db.delete(_table);
  }
}