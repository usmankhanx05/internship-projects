package com.maanovate.user_interface

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
