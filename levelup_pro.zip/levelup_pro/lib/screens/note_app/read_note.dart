import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:supabase_pro/providers/note_provider.dart';

class ReadNote extends StatefulWidget {
  const ReadNote({super.key});

  @override
  State<ReadNote> createState() => _ReadNoteState();
}

class _ReadNoteState extends State<ReadNote> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<NoteProvider>().loadNotes();
    });
  }

  @override
  Widget build(BuildContext context) {
    final noteProvider = context.watch<NoteProvider>();

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text(
          'Notes',
          style: TextStyle(fontWeight: FontWeight.w700),
        ),
        actions: [
          IconButton(
            onPressed: () => context.read<NoteProvider>().loadNotes(),
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: noteProvider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : noteProvider.notes.isEmpty
          ? const Center(
        child: Text(
          'No notes found',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
        ),
      )
          : ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: noteProvider.notes.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final note = noteProvider.notes[index];

          return Card(
            elevation: 3,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(18),
            ),
            child: ListTile(
              onTap: () {
                Navigator.pushNamed(
                  context,
                  '/update',
                  arguments: note,
                );
              },
              title: Text(
                note['title']?.toString() ?? '',
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              subtitle: Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(note['description']?.toString() ?? ''),
              ),
              trailing: IconButton(
                onPressed: () async {
                  final ok =
                  await context.read<NoteProvider>().deleteNote(
                    note['id'],
                  );

                  if (!mounted) return;

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        ok ? 'Note deleted' : 'Delete failed',
                      ),
                    ),
                  );
                },
                icon: const Icon(Icons.delete),
              ),
            ),
          );
        },
      ),
    );
  }
}