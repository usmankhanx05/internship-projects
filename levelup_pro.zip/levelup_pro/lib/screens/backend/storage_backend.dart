import 'dart:io';

import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class StorageBackend {
  final SupabaseClient supabase = Supabase.instance.client;

  Future<XFile?> pickImage() async {
    return ImagePicker().pickImage(source: ImageSource.camera);
  }

  Future<String> uploadImage(XFile image) async {
    final file = File(image.path);
    final fileName = DateTime.now().millisecondsSinceEpoch.toString();
    final path = 'uploads/$fileName.png';

    await supabase.storage.from('myimages').upload(path, file);
    return supabase.storage.from('myimages').getPublicUrl(path);
  }
}