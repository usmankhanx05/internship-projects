import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class NoteProvider extends ChangeNotifier {
  final SupabaseClient _supabase = Supabase.instance.client;

  List<Map<String, dynamic>> notes = [];
  bool isLoading = false;
  String? errorMessage;

  Future<void> loadNotes() async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    try {
      final data = await _supabase
          .from('notetable')
          .select()
          .order('id', ascending: false);

      notes = List<Map<String, dynamic>>.from(data);
    } catch (e) {
      errorMessage = e.toString();
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  Future<bool> addNote(String title, String description) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    try {
      await _supabase.from('notetable').insert({
        'title': title.trim(),
        'description': description.trim(),
      });

      await loadNotes();
      return true;
    } catch (e) {
      errorMessage = e.toString();
      isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> updateNote(dynamic id, String title, String description) async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();

    try {
      await _supabase.from('notetable').update({
        'title': title.trim(),
        'description': description.trim(),
      }).eq('id', id);

      await loadNotes();
      return true;
    } catch (e) {
      errorMessage = e.toString();
      isLoading = false;
      notifyListeners();
      return false;
    }
  }

  Future<bool> deleteNote(dynamic id) async {
    try {
      await _supabase.from('notetable').delete().eq('id', id);
      await loadNotes();
      return true;
    } catch (e) {
      errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }
}