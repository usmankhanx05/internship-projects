import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:supabase_pro/providers/auth_provider.dart';
import 'package:supabase_pro/providers/note_provider.dart';
import 'package:supabase_pro/screens/auth_screen/login_screen.dart';
import 'package:supabase_pro/screens/auth_screen/signup_screen.dart';
import 'package:supabase_pro/screens/home_screen.dart';
import 'package:supabase_pro/screens/note_app/add_note_screen.dart';
import 'package:supabase_pro/screens/note_app/read_note.dart';
import 'package:supabase_pro/screens/profile.dart';
import 'package:supabase_pro/screens/update_screen.dart';
import 'package:supabase_pro/splash_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(

    url: 'https://wmylnglgbpnlxsmfppza.supabase.co',
    anonKey:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndteWxuZ2xnYnBubHhzbWZwcHphIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU1Nzg5MzcsImV4cCI6MjA5MTE1NDkzN30.8HqZCysqhL_TBpJrrF8acPHXOB3gEYUoR4RmNb3ufio',
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => NoteProvider()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Supabase Pro',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.black),
        ),
        initialRoute: '/splash',
        routes: {
          '/splash': (context) => const SplashScreen(),
          '/login': (context) => const LoginScreen(),
          '/signup': (context) => const SignupScreen(),
          '/home': (context) => const HomeScreen(),
          '/add': (context) => const AddNoteScreen(),
          '/notes': (context) => const ReadNote(),
          '/profile': (context) => const Profile(),
        },
        onGenerateRoute: (settings) {
          if (settings.name == '/update') {
            final note = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (_) => UpdateScreen(showNote: note),
            );
          }
          return null;
        },
      ),
    );
  }
}