package com.example.supabase_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
