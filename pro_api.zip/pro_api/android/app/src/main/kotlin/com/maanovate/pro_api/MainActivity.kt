package com.maanovate.pro_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
