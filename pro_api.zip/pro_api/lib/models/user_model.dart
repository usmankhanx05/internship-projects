class UserModel {
  int id;
  String token;

  UserModel({required this.id, required this.token});

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? 0,
      token: json['token'] ?? '',
    );
  }
}