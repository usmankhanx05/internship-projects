import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/user_model.dart';
import '../models/news_model.dart';

class ApiService {

  // 🔐 LOGIN
  static Future<UserModel?> login(String email, String pass) async {

    final resp = await http.post(
      Uri.parse('https://reqres.in/api/login'),

      headers: {
        "Content-Type": "application/json",
        "x-api-key": "reqres-free-v1" // ✅ ADD THIS
      },

      body: jsonEncode({
        "email": email,
        "password": pass,
      }),
    );

    print(resp.body);

    if (resp.statusCode == 200) {
      return UserModel.fromJson(jsonDecode(resp.body));
    }

    return null;
  }  // NEWS
  static Future<List<NewsModel>> getNews() async {
    final resp = await http.get(Uri.parse(
        'https://newsapi.org/v2/everything?q=tesla&sortBy=publishedAt&apiKey=62e155b341e840f18bf70faedd966fcf'));

    final data = jsonDecode(resp.body);
    List list = data['articles'];

    return list.map((e) => NewsModel.fromJson(e)).toList();
  }
}