import 'package:flutter/material.dart';
import '../models/news_model.dart';
import '../services/api_service.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback toggleTheme;

  const HomeScreen({super.key, required this.toggleTheme});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  late Future<List<NewsModel>> news;

  @override
  void initState() {
    super.initState();
    news = ApiService.getNews();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white24,
        title: Text('Tesla News', style: TextStyle(
fontWeight: .bold,

        ),),
         centerTitle: true,
         actions: [

          // DARK MODE
          IconButton(
            onPressed: widget.toggleTheme,
            icon: Icon(Icons.brightness_6),
          ),

          //  LOGOUT
          IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (_) => LoginScreen(toggleTheme: widget.toggleTheme),
                ),
              );
            },
            icon: Icon(Icons.logout),
          )
        ],
      ),
backgroundColor: Colors.blueGrey.shade300,
      body: FutureBuilder<List<NewsModel>>(
        future: news,
        builder: (context, snapshot) {

          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          var data = snapshot.data!;

          return ListView.builder(
            itemCount: data.length,
            itemBuilder: (context, index) {

              var news = data[index];

              return Card(
                color: Colors.grey.shade300,
                margin: EdgeInsets.all(10),
                child: Column(
                  children: [

                    news.image != ''
                        ? Image.network(news.image)
                        : SizedBox(),

                    ListTile(
                      title: Text(news.title),
                      subtitle: Text(news.description),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}